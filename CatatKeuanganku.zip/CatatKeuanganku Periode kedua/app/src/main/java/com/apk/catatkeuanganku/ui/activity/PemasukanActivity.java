package com.apk.catatkeuanganku.ui.activity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.apk.catatkeuanganku.R;
import com.apk.catatkeuanganku.database.AppDatabase;
import com.apk.catatkeuanganku.database.TransactionEntity;
import com.apk.catatkeuanganku.utils.LocaleHelper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PemasukanActivity extends AppCompatActivity {

    private EditText etNama, etNominal;
    private TextView tvTanggal;
    private ImageButton btnPilihTanggal;
    private Button btnSimpan;
    private AppDatabase db;
    private Calendar calendar;
    private ImageButton btnBack;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }
    // =======================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pemasukan);

        etNama = findViewById(R.id.et_nama);
        etNominal = findViewById(R.id.et_nominal);
        tvTanggal = findViewById(R.id.tv_tanggal);
        btnPilihTanggal = findViewById(R.id.btn_pilih_tanggal);
        btnSimpan = findViewById(R.id.btn_simpan);
        btnBack = findViewById(R.id.btn_back);

        db = AppDatabase.getDatabase(this);
        calendar = Calendar.getInstance();
        updateDateLabel();

        // Listener
        btnPilihTanggal.setOnClickListener(v -> showDatePicker());
        btnSimpan.setOnClickListener(v -> saveTransaction("pemasukan")); // Tipe "pemasukan"
        btnBack.setOnClickListener(v -> onBackPressed());
    }

    private void showDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = (view, year, monthOfYear, dayOfMonth) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, monthOfYear);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateDateLabel();
        };

        new DatePickerDialog(this, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void updateDateLabel() {
        Locale currentLocale = getResources().getConfiguration().locale;
        String format = "dd MMMM yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(format, currentLocale);
        tvTanggal.setText(sdf.format(calendar.getTime()));
    }

    private void saveTransaction(String type) {
        String name = etNama.getText().toString();
        String nominalStr = etNominal.getText().toString();
        String date = tvTanggal.getText().toString();

        if (name.isEmpty() || nominalStr.isEmpty() || nominalStr.equals("0")) {
            Toast.makeText(this, getString(R.string.validation_empty_fields), Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            long amount = Long.parseLong(nominalStr);
            insertTransaction(name, amount, date, type);
        } catch (NumberFormatException e) {
            Toast.makeText(this, getString(R.string.validation_invalid_nominal), Toast.LENGTH_SHORT).show();
        }
    }

    private void insertTransaction(String name, long amount, String date, String type) {
        executor.execute(() -> {
            TransactionEntity transaction = new TransactionEntity(name, amount, date, type);
            db.transactionDao().insert(transaction);

            runOnUiThread(() -> {
                String successMsg = String.format(getString(R.string.toast_save_success), type.toUpperCase());
                Toast.makeText(PemasukanActivity.this, successMsg, Toast.LENGTH_SHORT).show();
                finish();
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.fade_out);
            });
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.fade_out);
    }
}