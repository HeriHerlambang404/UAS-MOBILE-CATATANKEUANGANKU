package com.apk.catatkeuanganku.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apk.catatkeuanganku.R;
import com.apk.catatkeuanganku.database.AppDatabase;
import com.apk.catatkeuanganku.database.TransactionEntity;
import com.apk.catatkeuanganku.ui.adapter.TransactionAdapter;
import com.apk.catatkeuanganku.utils.LocaleHelper;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TextView tvSaldo, tvGreeting;
    private Button btnPemasukan, btnPengeluaran, btnRiwayat;
    private RecyclerView rvLastTransactions;
    private TransactionAdapter adapter;
    private AppDatabase db;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_CatatKeuanganku);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSaldo = findViewById(R.id.tv_saldo);
        tvGreeting = findViewById(R.id.greeting);
        btnPemasukan = findViewById(R.id.btn_pemasukan);
        btnPengeluaran = findViewById(R.id.btn_pengeluaran);
        btnRiwayat = findViewById(R.id.btn_lihat_riwayat);

        // Panggil fungsi greeting pintar kita
        displayWelcomeMessage();

        rvLastTransactions = findViewById(R.id.rv_last_transactions);
        rvLastTransactions.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TransactionAdapter(this);
        rvLastTransactions.setAdapter(adapter);

        db = AppDatabase.getDatabase(this);

        btnPemasukan.setOnClickListener(v -> navigateTo(PemasukanActivity.class));
        btnPengeluaran.setOnClickListener(v -> navigateTo(PengeluaranActivity.class));
        btnRiwayat.setOnClickListener(v -> navigateTo(RiwayatActivity.class));
    }

    private void displayWelcomeMessage() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        String countryCode = prefs.getString("country_iso", "ID");

        String greeting;
        String countryName;

        switch (countryCode.toUpperCase()) {
            case "ID":
                greeting = "Selamat Datang di";
                countryName = "Indonesia";
                break;
            case "MY":
                greeting = "Selamat Datang ke";
                countryName = "Malaysia";
                break;
            case "SG":
                greeting = "Welcome to";
                countryName = "Singapore";
                break;
            case "TH":
                greeting = "Yindi txnrab su";
                countryName = "ประเทศไทย"; // Thailand
                break;
            case "VN":
                greeting = "Chao Mung Den";
                countryName = "Việt Nam";
                break;
            case "PH":
                greeting = "Maligayang pagdating sa";
                countryName = "Pilipinas"; // Filipina
                break;
            case "BN":
                greeting = "Selamat Datang ke";
                countryName = "Brunei Darussalam";
                break;
            case "KH":
                greeting = "saumosvakom mokkan";
                countryName = "Kamboja"; // Kamboja
                break;
            case "LA":
                greeting = "nyinditonhab";
                countryName = "Laos"; // Laos
                break;
            case "MM":
                greeting = "mhakyaosopartaal";
                countryName = "Myanmar"; // Myanmar
                break;
            case "TL":
                greeting = "Benvindo mai";
                countryName = "Timor-Leste";
                break;
            case "RU":
                greeting = "dobro pozhalovat v";
                countryName = "Rusia"; // Rusia
                break;
            case "JP":
                greeting = "Yokoso";
                countryName = "Japan"; // Jepang
                break;
            case "DE":
                greeting = "Willkommen in";
                countryName = "Deutschland"; // Jerman
                break;
            case "US":
                greeting = "Welcome to";
                countryName = "United States";
                break;
            case "GB":
                greeting = "Welcome to";
                countryName = "United Kingdom";
                break;


            default:
                greeting = "Welcome to";

                countryName = prefs.getString("detected_country", "your location");
                break;
        }

        String emoji = countryCodeToEmoji(countryCode);
        String welcomeFinal = greeting + " " + countryName + " " + emoji;
        tvGreeting.setText(welcomeFinal);
    }

    private String countryCodeToEmoji(String code) {
        if (code == null || code.length() != 2) return "";
        code = code.toUpperCase();
        int firstLetter = Character.codePointAt(code, 0) - 0x41 + 0x1F1E6;
        int secondLetter = Character.codePointAt(code, 1) - 0x41 + 0x1F1E6;
        return new String(Character.toChars(firstLetter)) + new String(Character.toChars(secondLetter));
    }

    private String formatRupiah(long number) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        return format.format(number).replace("Rp", "Rp ").replaceAll(",00", "");
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadSaldo();
        loadLast5Transactions();
    }

    private void loadSaldo() {
        executor.execute(() -> {
            Long saldo = db.transactionDao().getCurrentBalance();
            long finalSaldo = (saldo != null) ? saldo : 0L;
            runOnUiThread(() -> tvSaldo.setText(formatRupiah(finalSaldo)));
        });
    }

    private void loadLast5Transactions() {
        executor.execute(() -> {
            List<TransactionEntity> transactions = db.transactionDao().getLastNTransactions(5);
            runOnUiThread(() -> adapter.setTransactions(transactions));
        });
    }

    private void navigateTo(Class<?> cls) {
        startActivity(new Intent(this, cls));
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}