package com.apk.catatkeuanganku.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface TransactionDao {

    @Insert
    void insert(TransactionEntity transaction);

    // Mengambil semua transaksi, diurutkan dari terbaru (ID besar)
    @Query("SELECT * FROM transactions ORDER BY id DESC")
    List<TransactionEntity> getAllTransactions();

    // Query untuk menghitung saldo: JUMLAHKAN SEMUA KOLOM 'AMOUNT'
    // Logika sudah benar karena Pengeluaran disimpan sebagai NEGATIF.
    @Query("SELECT SUM(amount) FROM transactions")
    long getCurrentBalance(); // <--- PERBAIKAN KRITIS DI SINI!

    // BARU: Mengambil N transaksi terakhir (digunakan untuk 5 data di MainActivity)
    @Query("SELECT * FROM transactions ORDER BY id DESC LIMIT :limit")
    List<TransactionEntity> getLastNTransactions(int limit);

    // ... Query lainnya sama ...
    @Query("SELECT * FROM transactions WHERE type = 'pemasukan' ORDER BY id DESC LIMIT 2")
    List<TransactionEntity> getLatestIncome();

    @Query("SELECT * FROM transactions WHERE type = 'pengeluaran' ORDER BY id DESC LIMIT 2")
    List<TransactionEntity> getLatestExpense();

    // Query untuk menghapus transaksi
    @Query("DELETE FROM transactions WHERE id = :transactionId")
    void deleteTransaction(int transactionId);
}