package com.apk.catatkeuanganku.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "transactions")
public class TransactionEntity {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "name")
    public String name;

    @ColumnInfo(name = "amount")
    public long amount; // Gunakan long untuk nominal uang

    @ColumnInfo(name = "date")
    public String date; // Simpan tanggal sebagai String (format tanggal)

    @ColumnInfo(name = "type")
    public String type; // Nilainya: "pemasukan" atau "pengeluaran"

    // Constructor untuk insert data
    public TransactionEntity(String name, long amount, String date, String type) {
        this.name = name;
        this.amount = amount;
        this.date = date;
        this.type = type;
    }

    // --- Getter (Untuk mengambil data dari database) ---
    public int getId() { return id; }
    public String getName() { return name; }
    public long getAmount() { return amount; }
    public String getDate() { return date; }
    public String getType() { return type; }

    // Setter (Opsional, tapi untuk kelengkapan)
    public void setId(int id) { this.id = id; }
}