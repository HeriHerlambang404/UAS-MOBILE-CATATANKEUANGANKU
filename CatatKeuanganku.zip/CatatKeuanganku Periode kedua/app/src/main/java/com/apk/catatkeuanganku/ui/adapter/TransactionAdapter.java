package com.apk.catatkeuanganku.ui.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.apk.catatkeuanganku.R;
import com.apk.catatkeuanganku.database.TransactionEntity;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {

    private List<TransactionEntity> transactions;
    private Context context;

    public TransactionAdapter(Context context) {
        this.context = context;
    }

    public void setTransactions(List<TransactionEntity> transactions) {
        this.transactions = transactions;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        TransactionEntity currentItem = transactions.get(position);
        holder.bind(currentItem);
    }

    @Override
    public int getItemCount() {
        return transactions != null ? transactions.size() : 0;
    }

    public class TransactionViewHolder extends RecyclerView.ViewHolder {
        private TextView tvName, tvDate, tvAmount;
        private ImageView ivIcon;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_transaction_name);
            tvDate = itemView.findViewById(R.id.tv_transaction_date);
            tvAmount = itemView.findViewById(R.id.tv_transaction_amount);
            ivIcon = itemView.findViewById(R.id.iv_type_icon);
        }

        public void bind(TransactionEntity transaction) {
            tvName.setText(transaction.getName());
            tvDate.setText(transaction.getDate());

            boolean isIncome = transaction.getType().equals("pemasukan");

            if (isIncome) {
                tvAmount.setTextColor(Color.parseColor("#4CAF50"));
                ivIcon.setImageResource(R.drawable.ic_income2);
                ivIcon.setBackgroundColor(Color.parseColor("#C8E6C9"));
            } else {
                tvAmount.setTextColor(Color.parseColor("#F44336"));
                ivIcon.setImageResource(R.drawable.ic_expense2);
                ivIcon.setBackgroundColor(Color.parseColor("#FFE0B2"));
            }

            tvAmount.setText(formatRupiah(transaction.getAmount()));
        }

        private String formatRupiah(long number) {
            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
            return format.format(Math.abs(number)).replace("IDR", "Rp. ").trim();
        }
    }
}