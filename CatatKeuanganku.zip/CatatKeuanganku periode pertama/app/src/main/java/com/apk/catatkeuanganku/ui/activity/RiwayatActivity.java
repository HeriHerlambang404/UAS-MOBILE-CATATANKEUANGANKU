package com.apk.catatkeuanganku.ui.activity;

import android.content.Context; // <-- IMPORT BARU untuk attachBaseContext
import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apk.catatkeuanganku.R;
import com.apk.catatkeuanganku.database.AppDatabase;
import com.apk.catatkeuanganku.database.TransactionEntity;
import com.apk.catatkeuanganku.ui.adapter.TransactionAdapter;
import com.apk.catatkeuanganku.utils.LocaleHelper; // <-- IMPORT BARU untuk LocaleHelper

import java.util.List;
import java.util.concurrent.ExecutorService; // <-- IMPORT BARU
import java.util.concurrent.Executors; // <-- IMPORT BARU

public class RiwayatActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TransactionAdapter adapter;
    private AppDatabase db;
    private ImageButton btnBack;

    // Solusi Modern: Ganti AsyncTask dengan ExecutorService
    private final ExecutorService executor = Executors.newSingleThreadExecutor(); // <-- BARU

    // =======================================================
    // PERUBAHAN KRITIS 1: TAMBAH attachBaseContext
    // Fungsi ini memastikan Locale yang disetel di SplashScreen dipertahankan
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }
    // =======================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat);

        // Inisialisasi Database
        db = AppDatabase.getDatabase(this);

        // Setup Tombol Kembali
        btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(v -> onBackPressed());

        // Setup RecyclerView
        recyclerView = findViewById(R.id.rv_transactions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Setup Adapter
        adapter = new TransactionAdapter(this);
        recyclerView.setAdapter(adapter);

        // Muat data menggunakan ExecutorService
        loadAllTransactions(); // <-- DIGANTI
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Muat ulang data setiap kali kembali ke halaman ini
        loadAllTransactions(); // <-- DIGANTI
    }

    // =======================================================
    // PERUBAHAN KRITIS 2: Ganti AsyncTask dengan Executors
    // =======================================================

    /**
     * Muat semua transaksi dari database menggunakan ExecutorService.
     */
    private void loadAllTransactions() {
        executor.execute(() -> {
            // Operasi database di thread latar belakang
            List<TransactionEntity> transactions = db.transactionDao().getAllTransactions();

            // Pindah ke Main/UI Thread untuk update RecyclerView
            runOnUiThread(() -> {
                adapter.setTransactions(transactions);
            });
        });
    }

    // METHOD WAJIB untuk tombol back dan animasi
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.fade_out);
    }
}
// Hapus Class LoadAllTransactionsTask yang lama!