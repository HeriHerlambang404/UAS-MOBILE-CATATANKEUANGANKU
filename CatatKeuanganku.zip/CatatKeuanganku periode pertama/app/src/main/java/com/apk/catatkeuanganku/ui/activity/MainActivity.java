package com.apk.catatkeuanganku.ui.activity;

import android.content.Context; // Import untuk attachBaseContext
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apk.catatkeuanganku.R;
import com.apk.catatkeuanganku.database.AppDatabase;
import com.apk.catatkeuanganku.database.TransactionEntity;
import com.apk.catatkeuanganku.ui.adapter.TransactionAdapter;
import com.apk.catatkeuanganku.utils.LocaleHelper; // Import LocaleHelper

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService; // Import untuk Executors
import java.util.concurrent.Executors; // Import untuk Executors
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private TextView tvSaldo;
    private Button btnPemasukan, btnPengeluaran, btnRiwayat;
    private RecyclerView rvLastTransactions;
    private TransactionAdapter adapter;
    private AppDatabase db;

    // --- Solusi Modern: Ganti AsyncTask dengan ExecutorService ---
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    // --- PERUBAHAN KRITIS 1: Tambahkan attachBaseContext ---
    // Fungsi ini memastikan Locale yang disetel di SplashScreen dipertahankan
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Ganti tema splash kembali ke tema aplikasi normal
        setTheme(R.style.Theme_CatatKeuanganku);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Inisialisasi Views
        tvSaldo = findViewById(R.id.tv_saldo);
        btnPemasukan = findViewById(R.id.btn_pemasukan);
        btnPengeluaran = findViewById(R.id.btn_pengeluaran);
        btnRiwayat = findViewById(R.id.btn_lihat_riwayat);

        // Inisialisasi RecyclerView untuk 5 transaksi terakhir
        rvLastTransactions = findViewById(R.id.rv_last_transactions);
        rvLastTransactions.setLayoutManager(new LinearLayoutManager(this));

        // Setup Adapter
        adapter = new TransactionAdapter(this);
        rvLastTransactions.setAdapter(adapter);
        rvLastTransactions.setNestedScrollingEnabled(false);

        // 2. Inisialisasi Database
        db = AppDatabase.getDatabase(this);

        // 3. Listener Navigasi
        btnPemasukan.setOnClickListener(v -> navigateTo(PemasukanActivity.class));
        btnPengeluaran.setOnClickListener(v -> navigateTo(PengeluaranActivity.class));
        btnRiwayat.setOnClickListener(v -> navigateTo(RiwayatActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Memanggil fungsi baru yang menggunakan Executors
        loadSaldo();
        loadLast5Transactions();
    }

    private void navigateTo(Class<?> activityClass) {
        Intent intent = new Intent(MainActivity.this, activityClass);
        startActivity(intent);
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.fade_out);
    }

    /**
     * Fungsi utilitas untuk format Rupiah (Rp) secara paksa di semua Locale.
     */
    private String formatRupiah(long number) {
        // 1. Gunakan Locale Indonesia secara eksplisit untuk pemformatan angka
        Locale indonesianLocale = new Locale("in", "ID");
        NumberFormat format = NumberFormat.getCurrencyInstance(indonesianLocale);

        // 2. Konversi hasil format ke String
        String formatted = format.format(number);

        // 3. Manipulasi String untuk mendapatkan format 'Rp' yang bersih:
        formatted = formatted.replaceAll("[,.]\\d{2}$", ""); // Hapus desimal

        String currencySymbol = formatted.replaceAll("[\\d\\s.,]", "").trim(); // Dapatkan simbol

        if (!currencySymbol.isEmpty()) {
            formatted = formatted.replaceAll(Pattern.quote(currencySymbol), "").trim(); // Hapus simbol
        }

        if (number == 0) {
            return "Rp0";
        }

        return "Rp" + formatted;
    }


    // --- PERUBAHAN KRITIS 2: Ganti LoadSaldoTask (AsyncTask) dengan Executors ---
    private void loadSaldo() {
        executor.execute(() -> {
            // Operasi database di thread latar belakang
            Long saldo = db.transactionDao().getCurrentBalance();

            // Pindah ke Main/UI Thread untuk update UI
            runOnUiThread(() -> {
                tvSaldo.setText(formatRupiah(saldo));
            });
        });
    }

    // --- PERUBAHAN KRITIS 3: Ganti LoadLast5TransactionsTask (AsyncTask) dengan Executors ---
    private void loadLast5Transactions() {
        executor.execute(() -> {
            // Operasi database di thread latar belakang
            List<TransactionEntity> transactions = db.transactionDao().getLastNTransactions(5);

            // Pindah ke Main/UI Thread untuk update UI
            runOnUiThread(() -> {
                adapter.setTransactions(transactions);
            });
        });
    }

    // Catatan: AsyncTask Class yang lama (LoadSaldoTask dan LoadLast5TransactionsTask)
    // telah dihapus untuk menghilangkan peringatan deprecated API.
}