package com.apk.catatkeuanganku.ui.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.apk.catatkeuanganku.R;
import com.apk.catatkeuanganku.utils.LocaleHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class SplashScreen extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    // Waktu tunggu total splash screen (5 detik)
    private static final long SPLASH_DELAY_MS = 5000;
    // Waktu tunggu maksimal lokasi (4 detik)
    private static final long LOCATION_TIMEOUT_MS = 4000;

    private FusedLocationProviderClient fusedLocationClient;
    private TextView locationText;
    private TextView welcomeSplashText;
    private ImageView ivCountryFlag;

    private Handler handler;
    // Variabel untuk memastikan transisi hanya terjadi sekali
    private final AtomicBoolean isTransitioned = new AtomicBoolean(false);

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // INISIALISASI
        locationText = findViewById(R.id.locationText);
        welcomeSplashText = findViewById(R.id.welcomeSplashText);
        ivCountryFlag = findViewById(R.id.iv_country_flag);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        handler = new Handler(Looper.getMainLooper());

        checkLocationPermission(); // MULAI PROSES LOKASI

        // Teks awal saat proses deteksi dimulai
        locationText.setText("Mendeteksi Lokasi...");
    }

    // ================== FUNGSI DETEKSI LOKASI DAN LOCALE ==================

    private void setAppLocale(String localeCode) {
        if (localeCode != null) {
            LocaleHelper.setLocale(this, localeCode);
        }
    }

    private String getLocaleCode(String countryName) {
        if (countryName.equalsIgnoreCase("Indonesia")) {
            ivCountryFlag.setImageResource(R.drawable.ic_flag_id);
            return "in";
        } else if (countryName.equalsIgnoreCase("Germany")) { // TAMBAHKAN INI
            ivCountryFlag.setImageResource(R.drawable.ic_flag_de); // Pastikan resource ini ada
            return "de";
        } else if (countryName.equalsIgnoreCase("Malaysia")) {
            ivCountryFlag.setImageResource(R.drawable.ic_flag_ms);
            return "ms";
        } else if (countryName.equalsIgnoreCase("Japan")) {
            ivCountryFlag.setImageResource(R.drawable.ic_flag_ja);
            return "ge";
        } else if (countryName.equalsIgnoreCase("United States") || countryName.equalsIgnoreCase("USA")) {
            ivCountryFlag.setImageResource(R.drawable.ic_flag_usa);
            return "en";
        } else if (countryName.equalsIgnoreCase("Rusia")) {
            ivCountryFlag.setImageResource(R.drawable.ic_flag_rusia);
            return "ru";
        } else {
            // Gunakan bendera default/unknown jika negara tidak dikenali
            ivCountryFlag.setImageResource(R.drawable.ic_flag_unknown);
            return null;
        }
    }

    private void updateLocalizedTextViews(String countryName) {
        // Tampilkan ucapan Selamat Datang sesuai bahasa (mengambil dari strings.xml yang baru)
        welcomeSplashText.setText(getString(R.string.welcome_splash_text));

        // Tampilkan nama negara sesuai bahasa
        locationText.setText(getString(R.string.location_label) + countryName);
        ivCountryFlag.setVisibility(View.VISIBLE);
    }

    // ================== FUNGSI BARU (LOGIKA LOKASI & TRANSISI) ==================

    /**
     * Memastikan transisi ke MainActivity hanya terjadi sekali, setelah SPLASH_DELAY_MS.
     */
    private synchronized void delayedTransitionToMain() {
        if (isTransitioned.compareAndSet(false, true)) {
            handler.postDelayed(() -> {
                startActivity(new Intent(SplashScreen.this, MainActivity.class));
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }, SPLASH_DELAY_MS);
        }
    }

    /**
     * Meminta izin lokasi jika belum diberikan.
     */
    private void checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            getUserLocation();
        }
    }

    /**
     * Mendapatkan lokasi menggunakan FusedLocationProviderClient.
     */
    private void getUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            locationText.setText(getString(R.string.permission_denied));
            welcomeSplashText.setText(getString(R.string.welcome_splash_text));
            delayedTransitionToMain();
            return;
        }

        // Safety Net: Timeout untuk mencegah splash screen macet
        handler.postDelayed(() -> {
            if (!isTransitioned.get()) {
                locationText.setText(getString(R.string.location_timeout));
                welcomeSplashText.setText(getString(R.string.welcome_splash_text));
                delayedTransitionToMain(); // Pindah ke main meskipun timeout
            }
        }, LOCATION_TIMEOUT_MS);

        Task<Location> locationTask = fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY, null
        );

        locationTask.addOnSuccessListener(this, location -> {
            if (!isTransitioned.get()) {
                if (location != null) {
                    getCountryFromLocation(location); // Lokasi sukses, lanjut ke Geocoder
                } else {
                    locationText.setText(getString(R.string.location_unavailable));
                    welcomeSplashText.setText(getString(R.string.welcome_splash_text));
                }
                delayedTransitionToMain();
            }
        }).addOnFailureListener(e -> {
            if (!isTransitioned.get()) {
                locationText.setText("Gagal: " + e.getMessage());
                welcomeSplashText.setText(getString(R.string.welcome_splash_text));
                delayedTransitionToMain();
            }
        });
    }

    /**
     * Mengubah koordinat (Location) menjadi nama negara menggunakan Geocoder.
     */
    private void getCountryFromLocation(Location location) {
        // Geocoder menggunakan Locale default perangkat untuk membantu terjemahan
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses =
                    geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if (addresses != null && !addresses.isEmpty()) {
                String countryName = addresses.get(0).getCountryName();

                // 1. Dapatkan kode Locale dan set bendera
                String localeCode = getLocaleCode(countryName);

                // 2. Terapkan perubahan Locale
                setAppLocale(localeCode);

                // 3. Perbarui teks di splash screen (akan dimuat dalam bahasa baru)
                updateLocalizedTextViews(countryName);

            } else {
                locationText.setText(getString(R.string.geocoder_failed));
            }
        } catch (IOException e) {
            locationText.setText("Geocoder Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Menangani hasil permintaan izin lokasi.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Izin disetujui.", Toast.LENGTH_SHORT).show();
                getUserLocation(); // Lanjutkan jika izin diberikan
            } else {
                locationText.setText(getString(R.string.permission_denied));
                welcomeSplashText.setText(getString(R.string.welcome_splash_text));
                Toast.makeText(this, "Izin ditolak. Melanjutkan...", Toast.LENGTH_LONG).show();
                delayedTransitionToMain(); // Langsung pindah jika izin ditolak
            }
        }
    }
}