package com.apk.catatkeuanganku.ui.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.core.content.ContextCompat; // Tambahkan import ini untuk penggunaan warna yang lebih baik

import com.apk.catatkeuanganku.R;
import com.apk.catatkeuanganku.database.TransactionEntity;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {

    private List<TransactionEntity> transactions;
    private Context context;

    public TransactionAdapter(Context context) {
        this.context = context;
    }

    /**
     * Method ini dipanggil oleh RiwayatActivity dan MainActivity untuk memberikan data baru
     */
    public void setTransactions(List<TransactionEntity> transactions) {
        this.transactions = transactions;
        notifyDataSetChanged(); // Memberitahu RecyclerView untuk reload tampilan
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate (membuat) tampilan dari item_transaction.xml
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        // Menghubungkan data ke tampilan pada posisi tertentu
        TransactionEntity currentItem = transactions.get(position);
        holder.bind(currentItem);
    }

    @Override
    public int getItemCount() {
        // Jumlah item yang akan ditampilkan
        return transactions != null ? transactions.size() : 0;
    }

    // ViewHolder: Kelas yang memegang referensi (findViewById) dari tampilan item
    public class TransactionViewHolder extends RecyclerView.ViewHolder {
        private TextView tvName, tvDate, tvAmount;
        private ImageView ivIcon;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            // Pastikan ID ini sesuai dengan item_transaction.xml
            tvName = itemView.findViewById(R.id.tv_transaction_name);
            tvDate = itemView.findViewById(R.id.tv_transaction_date);
            tvAmount = itemView.findViewById(R.id.tv_transaction_amount);
            ivIcon = itemView.findViewById(R.id.iv_type_icon);
        }

        public void bind(TransactionEntity transaction) {
            tvName.setText(transaction.getName());
            tvDate.setText(transaction.getDate());

            // Variabel untuk menghemat kode
            boolean isIncome = transaction.getType().equals("pemasukan");

            // Tentukan warna dan ikon berdasarkan tipe transaksi
            if (isIncome) {
                // Gunakan ContextCompat.getColor jika kamu punya color resource,
                // jika tidak, kode Color.parseColor yang kamu pakai juga valid.
                tvAmount.setTextColor(Color.parseColor("#4CAF50")); // Hijau
                ivIcon.setImageResource(R.drawable.ic_income);
                ivIcon.setBackgroundColor(Color.parseColor("#C8E6C9")); // Mint Green
            } else {
                tvAmount.setTextColor(Color.parseColor("#F44336")); // Merah
                ivIcon.setImageResource(R.drawable.ic_expense);
                ivIcon.setBackgroundColor(Color.parseColor("#FFE0B2")); // Peach
            }

            // Set nominal yang sudah diformat Rupiah
            tvAmount.setText(formatRupiah(transaction.getAmount()));
        }

        // Utilitas untuk format Rupiah
        private String formatRupiah(long number) {
            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
            // Menggunakan fungsi Math.abs() agar nilai nominal selalu positif di tampilan,
            // meskipun kamu menyimpan pengeluaran sebagai nilai negatif (jika ada).
            return format.format(Math.abs(number)).replace("IDR", "Rp. ").trim();
        }
    }
}