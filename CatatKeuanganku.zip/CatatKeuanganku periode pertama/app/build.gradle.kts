plugins {
    alias(libs.plugins.android.application)
    // PENTING: Untuk Java/Annotation Processing di Kotlin DSL, kita tidak perlu 'kotlin-kapt'
    // Cukup pastikan Room Compiler ditambahkan di dependencies.
}

// Definisikan versi library di blok 'ext' atau 'properties' jika tidak menggunakan Version Catalog
val roomVersion = "2.6.1" // Versi stabil Room
val recyclerViewVersion = "1.3.2"
val cardViewVersion = "1.0.0"

android {
    namespace = "com.apk.catatkeuanganku"
    compileSdk = 36 // Gunakan versi stabil terbaru

    defaultConfig {
        applicationId = "com.apk.catatkeuanganku"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8 // Room API 2.6.1 merekomendasikan Java 8 atau lebih tinggi
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    // Dependensi yang sudah ada:
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // Test Dependensi:
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)

    // START: Dependensi Tambahan untuk CatatKeuanganku

    // 1. Room Database (Penyimpanan Data Lokal)
    implementation("androidx.room:room-runtime:$roomVersion")
    // Karena ini project Java, kita pakai 'annotationProcessor'
    // Tapi di Kotlin DSL, kita harus menggunakan 'ksp' jika projectnya Kotlin,
    // atau menggunakan 'annotationProcessor' dengan syntax yang benar

    // **PENTING: Karena Android Studio 7.0+ dan Gradle modern**
    // Jika kamu tetap ingin menggunakan Annotation Processor di KTS,
    // kamu harus menambahkan plugin KAPT atau KSP dan mengkonfigurasinya.
    // Namun, cara paling bersih di KTS untuk Room + Java adalah:
    // (Jika kamu belum menambahkan plugin Kotlin)

    // SOLUSI: Untuk Room di Java (Non-Kapt Project):
    // Kita gunakan 'implementation' untuk runtime dan 'annotationProcessor' di blok yang sesuai
    annotationProcessor("androidx.room:room-compiler:$roomVersion")

    // 2. UI Components (Untuk Desain Modern)
    implementation("androidx.recyclerview:recyclerview:$recyclerViewVersion") // Untuk RiwayatActivity
    implementation("androidx.cardview:cardview:$cardViewVersion") // Untuk item list yang cantik
    implementation("com.google.android.gms:play-services-location:21.0.1")

    // END: Dependensi Tambahan
}